<?php


$conn =new mysqli("localhost","root","","ci");

 if($conn->connect_error)
 
 {
 
   die("connection failed:".$conn->connect_error);
   
   }
   
   
   ?>

